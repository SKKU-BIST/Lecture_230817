#%% 자주쓰는 라이브러리 불러오기

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sklearn as sk
import seaborn as sns
import pickle

#%% 데이터 및 모델 불러오기

filepath = "C:/Users/LAB_6/OneDrive - 성균관대학교/바탕 화면/Practice_A/"

df = pd.read_csv(os.path.join(filepath + "Practice_A_Data.csv"),
                        encoding = 'CP949')

from keras.models import load_model
model = load_model(filepath+"Practice_Model.h5")

df['Time'] = pd.to_datetime(df['Time'])

start_date = pd.to_datetime('2022-06-22')
end_date = pd.to_datetime('2022-06-23')

df_ = df[(df['Time'] >= start_date) & (df['Time'] <= end_date)]

#%% 에러 모델 생성

# 하이퍼 파라미터 설정
# =============================================================================

#모델 에러 설정 
Bias =  1

Random = 0.1

Drift = 0.1 # 단위 (℃)  

Error_start_time = pd.to_datetime('2022-06-22  9:36:00 AM')

# 임계값 설정
threshold = 0.5 # 단위 (℃)

duration = 10 # 단위 (분)

# =============================================================================

Ground_truth = np.array(df_.loc[:,'냉수 환수온도'])
Error = Random*0.5*np.random.randn(len(df[(df['Time'] >= Error_start_time) & (df['Time'] <= end_date)])) + Bias
Error_time = len(Ground_truth)-len(Error)

Error_model = Ground_truth.copy()

for i in range(0,len(Error)):
    Error_model[i+Error_time] = Ground_truth[i+Error_time] + Error[i]

for i in range(0,len(Error)):
    
    if np.abs(Drift) <= 1:
        Error_model[i+Error_time] = Error_model[i+Error_time]
    elif Drift >= 0:
        Error_model[i+Error_time] = Error_model[i+Error_time] + (Drift)**((i)/180)
    else:
        Error_model[i+Error_time] = Error_model[i+Error_time] - (-Drift)**((i)/180)
        

#%% 벤치마크 모델 생성

x_test = df_.loc[:,['냉수 유량','냉수 공급온도','냉동기 전력량','냉수 공급/환수 배관 차압']]

def Normalize(df_,bound):
    df_norm = np.zeros(np.shape(df_))
    for i in range(0,np.shape(df_)[1]):
        # [0,1] 범위로 정규화 계산을 진행
        df_norm[:,[i]] = (df_[:,[i]]-bound[[i],0]) / (bound[[i],1]-bound[[i],0])
    return df_norm

with open(filepath+"Normalization_boundary","rb") as fi:
    Normalization_boundary = pickle.load(fi)   

output_norm_bound = Normalization_boundary[[0]]
Normalization_boundary = Normalization_boundary[1:]

x_test_norm = Normalize(np.array(x_test),Normalization_boundary)

Target_est_ = model.predict(x_test_norm)
Target_est = output_norm_bound[0,0] + Target_est_*(output_norm_bound[0,1]-output_norm_bound[0,0])
Target_est = Target_est[:,0]

#%% Time seires plot

plt.figure(figsize = (30,20))
plt.rc('axes',labelsize = 30)
plt.rc('axes',titlesize = 30)
plt.rc('xtick',labelsize = 30)
plt.rc('ytick',labelsize = 30)
plt.rc('legend', fontsize= 30)
plt.rc('figure',titlesize = 30)

plt.subplot(2,1,1)
plt.plot(np.arange(0,len(np.array(Ground_truth)),1) ,np.array(Ground_truth)
          , label = 'Ground truth', color = 'black', linestyle ='--')
plt.plot(np.arange(0,len(Target_est),1) ,Target_est
          , label = 'MLP model', color = 'dodgerblue')
plt.plot(np.arange(0,len(Error_model),1) ,Error_model
          , label = 'Error model', color = 'r')

plt.ylabel("Temperature (℃)",fontsize = 40)
plt.xlabel("Time (minutes)",fontsize = 30)
plt.legend(loc = 'upper right')

plt.grid()
plt.margins(x=0)

#%% FDD plot
R_Error = Error_model - Ground_truth
R_MLP = Error_model - Target_est 

plt.subplot(2,1,2)
plt.plot(np.arange(0,len(Ground_truth),1) ,R_Error
          , label = 'Error model - Ground truth', color = 'black',linestyle = '--')

plt.plot(np.arange(0,len(Target_est),1) ,R_MLP
          , label = 'Error model - MLP model', color = 'dodgerblue')

plt.axvline(Error_time, color='grey', alpha=1,linewidth = 2,linestyle = '--')
plt.annotate("Error occured!", xy=(Error_time, 0.5), xytext=(Error_time - 100, 1.5),
              color='grey', fontsize=30, rotation=0,
              arrowprops=dict(arrowstyle="->", color='grey'))


# 에러가 duration 이상인 지점 검출
for i in range(10,len(Ground_truth)): # 초기 가동시간 제외
    detect = len(Ground_truth)
    
    if all(np.abs(R_MLP[i-j]) >= threshold for j in range(duration)) :
        detect = i
        plt.axvline(detect-duration, color='r', alpha=1,linewidth = 2,linestyle = '--')
        plt.annotate("Error detected!", xy=(detect-duration, 0.5), xytext=(detect-duration - 100, -1.5),
                      color='r', fontsize=30, rotation=0,
                      arrowprops=dict(arrowstyle="->", color='r'))
        break

# 에러로 인지한 시점 이후로 Fault detect 실시
for i in range(detect-duration,len(Ground_truth)):
    
    if detect == len(Ground_truth):
        break
    
    elif np.abs(R_MLP[i]) >= threshold:
        plt.axvline(i, color='r', alpha=0.3)

plt.grid()
plt.margins(x=0)
plt.ylabel("Residual (℃)",fontsize = 40)
plt.xlabel("Time (minutes)",fontsize = 30)
plt.legend(loc = 'upper center', ncol = 4, bbox_to_anchor=(0.5,-0.2))
plt.subplots_adjust(wspace = 0, hspace = 0.3)
plt.tight_layout()
plt.show()

#%% 오차 행렬 (Confusion matrix) 생성

# 비정상-> 1, 정상 -> 0
True_label = np.zeros(shape = (len(Ground_truth)))
Pred_label = np.zeros(shape = (len(Ground_truth)))

for i in range(len(Ground_truth)):
    if i >= Error_time:
        True_label[i] = 1


for i in range(detect-duration, len(Ground_truth)):
    if detect == len(Ground_truth):
        break

    if np.abs(R_MLP[i]) >= threshold:    
        Pred_label[i] = 1

Result = pd.DataFrame({'True' : True_label,
                       'Pred' : Pred_label})

# 비정상을 비정상으로 진단 -> TP, 정상을 정상으로 진단 -> TN

TP = len(Result[(Result['True'] == 1) & (Result['Pred'] == 1)])
FP = len(Result[(Result['True'] == 0) & (Result['Pred'] == 1)])
FN = len(Result[(Result['True'] == 1) & (Result['Pred'] == 0)])
TN = len(Result[(Result['True'] == 0) & (Result['Pred'] == 0)])

Confusion = pd.DataFrame({'Abormal_MLP model' : [TP,FP],
                       'Normal_MLP model' : [FN,TN]})

#%% 데이터 시각화

plt.figure(figsize = (20,20))
plt.rc('axes',labelsize = 30)
plt.rc('axes',titlesize = 40)
plt.rc('xtick',labelsize = 40)
plt.rc('ytick',labelsize = 40)
plt.rc('legend', fontsize= 30)
plt.rc('figure',titlesize = 30)
plt.rc('font', size=50)

sns.heatmap(Confusion, annot = True, yticklabels=('Abnormal_Ground truth',"Normal_Ground truth"), 
            cmap = 'YlGn', fmt= ".5g",
            vmin = min(TP,FP,FN,TN), 
            vmax = max(TP,FP,FN,TN), 
            cbar = False)

plt.title("Confusion matrix")

#%% 모델 성능 평가 지표

from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score

RMSE_MLP = mean_squared_error(Ground_truth,Target_est)**(1/2)
RMSE_Error = mean_squared_error(Ground_truth,Error_model)**(1/2)

R2_MLP = r2_score(Ground_truth,Target_est)
R2_Error = r2_score(Ground_truth,Error_model)

Error_detected_time = Error_start_time + pd.Timedelta(minutes=detect-Error_time+1-duration)

if TP + FP == 0: 
    print('\n')
    print("Fail to detect error")
    print("-----------------------------------------------")
    accuracy = (TP + TN) / (TP + TN + FP + FN)
    print("Accuracy : " ,round(accuracy,3))
    recall = TP / (TP + FN )
    print("Recall : " ,round(recall,3))
    correct_alarm = TP / (TP + FN)
    print("Correct alarm : " ,round(correct_alarm,3))
    false_alarm = FP / (FP + TN)
    print("False_alarm : " ,round(false_alarm,3)) 
    missing_alarm = FN / (TP + FN )
    print("Missing alarm : " ,round(missing_alarm,3))
    print("-----------------------------------------------")
else:
    print('\n')     
    print('MLP model accuracy')
    print("-----------------------------------------------")
    print("RMSE Result : " ,round(RMSE_MLP,3)) 
    print("R2 Result : " ,round(R2_MLP,3)) 
    print("-----------------------------------------------")
    print('\n')
    
    print('Error model accuracy')
    print("-----------------------------------------------")
    print("RMSE Result : " ,round(RMSE_Error,3)) 
    print("R2 Result : " ,round(R2_Error,3)) 
    print("-----------------------------------------------")
    print('\n')
    
    print('FDD result')
    print("-----------------------------------------------")
    accuracy = (TP + TN) / (TP + TN + FP + FN)
    print("Accuracy : " ,round(accuracy,3))
    precision = TP / (TP + FP)
    print("Precision : " ,round(precision,3)) 
    recall = TP / (TP + FN )
    print("Recall : " ,round(recall,3))
    F1_score = 2 * precision * recall / (precision + recall)
    print("F1 score : " ,round(F1_score,3))

    correct_alarm = (TN / (FP + TN)) * TP / (TP + FN )
    print("Correct alarm : " ,round(correct_alarm,3))
    false_alarm = FP / (FP + TN)
    print("False_alarm : " ,round(false_alarm,3)) 
    missing_alarm = FN / (TP + FN )
    print("Missing alarm : " ,round(missing_alarm,3),'\n')
    
    print("Actual error start time    :",Error_start_time)
    print("Estimated error start time :",Error_detected_time)
    print("Delay time:",detect-Error_time+1,'minutes')
    print("-----------------------------------------------")
