# 자주 사용되는 Python library Import
import os
import numpy as np
import pandas as pd
from numpy import genfromtxt
from numpy import sqrt
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sklearn as sk
from scipy.stats import norm
import scipy
import pickle

#%% 데이터 불러오기

filepath = "C:/Users/LAB_6/OneDrive - 성균관대학교/바탕 화면/Practice_A/"

df = pd.read_csv(os.path.join(filepath+"Practice_A_Train.csv"),
                        index_col = 0,header = 0, encoding = 'CP949')

with open(filepath+"Normalization_boundary","rb") as fi:
    Normalization_boundary = pickle.load(fi)  

#%% 하이퍼 파라미터 설정

# =============================================================================

# 입력 변수 True / False로 표현
Water_flow = True                                         
Supply_temperature = True                                
Chiller_power = True                                     
Differential_pressure = True                              

# 학습기간
Train_period = 10000 # 단위 (분)

# 검증기간
Test_period = 1000 # 단위 (분)

# 모델 구조
Number_of_hidden_layer = 4 # 1개 이상 필요 
Number_of_node = 64 # 일반적으로 2의 배수
Epoch = 10 # 일반적으로 25의 배수
Learning_rate = 0.01 # 일반적으로 0.01 사용
# =============================================================================

#%% (3-2): 모델 학습과정

#모델 학습을 위한 Library 가져오기
import tensorflow
from tensorflow import keras
from keras.models import Sequential, Model
from keras.layers import Dense, Activation
from keras.optimizers import Adam
from keras.callbacks import TensorBoard
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
from keras.callbacks import EarlyStopping

df_train = df.iloc[0 : Train_period]
df_test = df.iloc[Train_period  : Test_period+Train_period ]

input_no = []

if Water_flow :
    input_no.append(1)
if Supply_temperature :
    input_no.append(2)
if Chiller_power:
    input_no.append(3)
if Differential_pressure:
    input_no.append(4)

input_no = sorted(input_no)
output_no = [0]

model_input = np.array(df_train.iloc[:,input_no])
model_output = np.array(df_train.iloc[:,output_no])

#모델 구조 설정
model = Sequential()
model.add(Dense(Number_of_node, activation = 'relu', input_dim=len(input_no)))
for _ in range(Number_of_hidden_layer):
    model.add(Dense(Number_of_node, activation='relu'))
model.add(Dense(1, activation='linear'))

# 모델 컴파일링
callback = keras.callbacks.EarlyStopping(monitor='val_loss', patience=5)
keras.optimizers.Adam(learning_rate = Learning_rate, epsilon=True, decay=0.9, amsgrad=False)
model.compile(loss='mean_squared_error',optimizer = "adam")
history = model.fit(model_input, model_output, batch_size=32, epochs=Epoch,
                    verbose=1, validation_split=0.2, shuffle=True)

#%% 모델로 추론한 변수 산출

output_norm_bound = Normalization_boundary[output_no,:]
xtest_ = np.array(df_test.iloc[:,input_no])
ytest_ = np.array(df_test.iloc[:,output_no])

ypred_ = model.predict(xtest_)

#정규화된 상태인 출력 변수 역정규화하기
ytest_rv_norm_ = output_norm_bound[0,0] + np.array(ytest_)*(output_norm_bound[0,1]-output_norm_bound[0,0])
ypred_rv_norm_ = output_norm_bound[0,0] + ypred_*(output_norm_bound[0,1]-output_norm_bound[0,0])

#모델 평가지표 R2 score, RMSE
R2_model_ = r2_score(ytest_rv_norm_,ypred_rv_norm_)
RMSE_model_ = mean_squared_error(ytest_rv_norm_,ypred_rv_norm_)**(1/2)

#모델 학습결과 콘솔창에 print
print("-----------------------------------------------")
print("Result for test dataset")
print("Model saved OK!")
print("R2 value:",round(R2_model_,3))
print("RMSE value:",round(RMSE_model_,5),"\x0A")
print("-----------------------------------------------")

#모델 시각화하기
plt.rcParams['font.family']='times new roman'
plt.rcParams['figure.figsize']=[30,10]
plt.rc('axes',labelsize = 35)
plt.rc('axes',titlesize = 35)
plt.rc('xtick',labelsize = 30)
plt.rc('ytick',labelsize = 30)
plt.rc('legend', fontsize= 30)
plt.rc('figure',titlesize = 35)

plt.figure()
plt.plot(np.arange(0,len(ytest_),1),ytest_rv_norm_ , label= 'True',color = 'magenta')
plt.plot(np.arange(0,len(ytest_),1),ypred_rv_norm_, label = 'Estimated',color = 'dodgerblue')
plt.xlabel("Episodes")
plt.ylabel("Variable")
plt.title('Test model')
plt.legend(loc = 'upper center', ncol = 4, bbox_to_anchor=(0.5,-0.2))
plt.grid()
plt.margins(x=0)

# 모델 저장하기
model.save(filepath+"Practice_Model.h5")


